import React from 'react'

function Header() {
  return (
    <h1 className='font-bold text-3xl text-center overflow-hidden bg-purple-900 text-white'>Event Horizon</h1>
  )
}

export default Header